/*
Program that guesses the number using a class
Aaron Ivan Gonzalez
04/15/2022
CS 110B
*/
#include <iostream>
#include <ctime>
#include "numGuesser.h"
using namespace std;

int main()
{
    numberGuesser littleGuesser(25,35);//calls function to play guess game

    cout << "The Midpoint is: " << littleGuesser.getCurrentGuess() << endl;//should return 30

    //calling higher() function adjusts the range of the higher parameter
    littleGuesser.higher();

    cout << "The Midpoint is: " << littleGuesser.getCurrentGuess() << endl;

    //call reset() function to reset values to original initalized values
    littleGuesser.reset();

    cout << "The Midpoint is: " << littleGuesser.getCurrentGuess() << endl;//should return 30

    //calling higher() function adjusts the range of the lower parameter
    littleGuesser.lower();

    cout << "The Midpoint is: " << littleGuesser.getCurrentGuess() << endl;
    return 0;
}


/*
The Midpoint is: 30
The Midpoint is: 33
The Midpoint is: 30
The Midpoint is: 27
*/
