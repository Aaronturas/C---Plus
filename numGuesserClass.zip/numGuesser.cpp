#include "numGuesser.h"
#include <iostream>
#include <cmath>
numberGuesser::numberGuesser()
{
    //initaialize default values for ranges
    l = 1;
    h = 100;
}

numberGuesser::numberGuesser(int lowerBound, int higherBound)
{
    l = lowerBound;
    h = higherBound;

    //original variables are set to bounds because we need them for reset() function
    lO = lowerBound;
    hO = higherBound;

}
void numberGuesser::higher() {
    int guess = getCurrentGuess();

    l = guess + 1;//set the lowerBound to the midpoint guess

}
void numberGuesser::lower() {
      int guess = getCurrentGuess();

    h = guess - 1;//set the higherBound to the midpoint guess
}
int numberGuesser::getCurrentGuess() {
    int low = l;
    int high = h;

     int mid = (low + high) / 2;
    return mid;
}

void numberGuesser::reset() {
    l = lO;
    h = hO;
};
