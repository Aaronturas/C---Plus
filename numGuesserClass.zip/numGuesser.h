#ifndef NUMGUESSER_H
#define NUMGUESSER_H


class numberGuesser
{
    public:
        numberGuesser();
        numberGuesser(int, int);
        void higher();
        void lower();
        int getCurrentGuess();
        void reset();
    private:
        int l, h, lO, hO;//l = low, h = high, LO = low Original, hO = Original
};

#endif // NUMGUESSER_H
